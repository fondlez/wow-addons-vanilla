--[[
	Bagnon Forever Localization file
		This provides a way to translate Bagnon_Forever into different languages.
--]]

--[[
	German
		Credit goes to Sarkan on Curse
--]]

if ( GetLocale() == "deDE" ) then
	--BAGNON_TITLE_FOREVERTOOLTIP = "<Doppel-Klick> um Charakter zu wechseln.";
	return;
end