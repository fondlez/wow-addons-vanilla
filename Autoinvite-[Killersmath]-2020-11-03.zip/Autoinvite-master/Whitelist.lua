WhiteList_Players = { 
  -- Tank
  [1]   = "Stunx";
  [2]   = "Nerrin";
  [3]   = "Xyhpa";
  [4]   = "Nadrieda";
  -- Warrior
  [5]   = "Sladey";
  [6]   = "Hakuhna";
  [7]   = "Dawayne";
  [8]   = "Maleficentt";
  [9]   = "Mastrif";
  [10]  = "Greendubz";
  -- Hunter
  [11]  = "Deadlyaim";
  [12]  = "Nightshann";
  [13]  = "Pimanych";
  -- Priest
  [14]  = "Allarra";
  [15]  = "Rhaeya";
  [16]  = "Bosit";
  [17]  = "Danielus";
  [18]  = "Terexin";
  [19]  = "Bunnyaggro";
  [20]  = "Matada";
  -- Mage
  [21]  = "Anuber";
  [22]  = "Micca";
  [23]  = "Mipinga";
  [24]  = "Ndrew";
  [25]  = "Netherias";
  [26]  = "Elsa";
  -- Paladin
  [27]  = "Andromedus";
  [28]  = "Gohk";
  [29]  = "Angrymonkey";
  [30]  = "Jodorowsky";
  [31]  = "Danideus";
  -- Rogue
  [32]  = "Dragoney";
  [33]  = "Furcifer";
  [34]  = "Ashassin";
  [35]  = "Mebouls";
  [36]  = "Dorfenstien";
  -- Warlock
  [37]  = "Lehstrange";
  [38]  = "Tyonidas";
  -- Druid
  [39]  = "Lustaria";
  [40]  = "Sandmia";
  [41]  = "Katniss";
};