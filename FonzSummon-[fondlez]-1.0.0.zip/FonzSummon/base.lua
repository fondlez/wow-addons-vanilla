local A = AceLibrary("AceAddon-2.0"):new("AceDebug-2.0", "AceConsole-2.0",
  "AceDB-2.0", "AceEvent-2.0", "AceHook-2.1", "FuBarPlugin-2.0")
FonzSummon = A
  
A.ver = "1.0.0"
A.addon_path = [[Interface\AddOns\FonzSummon]]