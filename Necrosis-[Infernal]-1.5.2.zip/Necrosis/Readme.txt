NECROSIS LdC
-------------------------------

- Original Idea : Infernal (http://www.revolvus.com/games/interface/necrosis/)
- First translation (in French which was not supported by the original
	mod) and improvements : Tilienna Thorondor
- Necrosis LdC maintainers : Lomig & Nyx from Kael'Thas

- Skins and French voices : Eliah from Ner'zhul
- German Version by Arne Meier
- Special thanks to Sadyre

- Contact : lomig@larmes-cenarius.net - nyx@larmes-cenarius.net


First of all, I apologize for my bad english, I will try to find someone
who can speak more fluently than me to improve my pieces of writing...



-------------------------------
1 - What is Necrosis ?
-------------------------------

Necrosis is a mod to help Warlocks managing their stones, shards and 
demon. No more, but no less... It actually can not make a coffee, but I
tried, I promise !


-------------------------------
2 - Why should I use Necrosis ?
-------------------------------

Because it is marvelous ! It is really cute, thanks to him you will not
be obliged to have one thousand buttons all over your screen, your
friends will be happy knowing they are protected by a stone, and they will
thank you when it will teach them how to summon a guy... Marvelous, I
said !

-------------------------------
3 - How does it work ?
-------------------------------

Really simple. My grandmother can do it.Oh, well, you can bet my
grandmother never intended to play online games. She thought that computers
were devil machines which can provide illness and death. I think it is a
shame not to be less narrowminded. Well, anyway...

How does it work ? Mmm...


Necrosis will provide you a sphere and 7 buttons.
Right click on the sphere will provide you the configuration menu.

- On the sphere, the number of soulshards you have
- A button to create / equip a fire stone
- A button to create / equip / use a spellstone
	Right click to create or equip
	Left click to create or use
- A button to create / use / give a healthstone
	With no target, npc, mobs or enemy target : Use the stone
	With a friendly player target : Give the stone
- A button to create / use a soulstone
	Use while targeting a friendly player : Use the stone on him
	Use while targeting something else : Use the stone on you
	Fortunately, you will not be able to use a stone as you already
		have full life... And if you want to cure already-fine-people
		only, you can try to become a Paladin instead !
- A button to summon your Steed
- A button to show you the demon menu from which you will be able to summon
	your demons, gain a Fel Domination...
- A button for Spell timers
	Spell timers will appear on the right of this button
	Right click on this button will use your Hearthstone

-------------------------------
4 - More functionnalities
-------------------------------

You can put the Necrosis Sphere wherever you want
You can put the Necrosis Buttons wherever you want

When you quit the game with a stone in off-hand, and then you re-enter the
world more than 30 minutes later, as your stones had faded, your first
soulbound off-hand item in your bags will be equiped

When you summon a player, Necrosis will pick up a sentence to ask your friends
to help you. I said "pick up" because there is several sentences available,
picked up randomly.

When you give a Soulstone protection to a friend by its button, Necrosis will
also pick up a sentence to tell

These sentences are written in the "Speech.lua" file, you can modify/add/remove
as many sentence as you wish


Most of your spells with cooldown will be shown by the Spell Timer... Most, but
not all ! It is quite difficult to time instant cast spells... Well I'll try to !

-------------------------------
5 - Help needed
-------------------------------

I can read english quite perfectly, but speaking or writing it, it is an ordeal...
So neither this text nor my "in game" sentences are "oxbridge" english. If you
you want me to correct vocabulary / spelling / grammar, you can mail me !

Please do not try to correct my French, I would be offended :P

If there is a bug with this mod, you can write me, explaining me how does the
bug happen, and giving me the whole and complete (and entire) (and full)
error message :P

-------------------------------
6 - Improvement
-------------------------------

If you think some functions are dumshit, if you add a brilliant stuff and think
people would like it, mail us !
