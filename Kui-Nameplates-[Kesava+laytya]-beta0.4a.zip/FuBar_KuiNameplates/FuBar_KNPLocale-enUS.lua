local L = AceLibrary("AceLocale-2.2"):new("FuBar_Kui-Nameplates")

L:RegisterTranslations("enUS", function() return {
	TOOLTIP_NAME = 		"FuBar Kui-Nameplates",
	TOOLTIP_HINT1 = 	"\n|cffeda55fLeft-Click|r for Kui-Nameplates Options.",
	TOOLTIP_NOTE =		"Access Kui-Nameplates Options.",
	["Kui-Nameplates"] = true,
	["Open Kui-Nameplates Options"] = true,	

} end)
