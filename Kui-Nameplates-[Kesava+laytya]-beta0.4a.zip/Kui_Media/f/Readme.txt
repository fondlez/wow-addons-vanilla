
 The following files are released under licenses which allow use in at least non-commercial applications.
	
 yanone.ttf, or Yanone Kaffeesatz Bold
 By Yanone @ yanone.de

 francois.ttf, or Francois One
 By New Typography @ newtypography.co.uk