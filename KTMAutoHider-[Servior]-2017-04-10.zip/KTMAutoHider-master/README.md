# KTMAutoHider
KTM Auto Hider from http://addons.us.to/addon/ktmautohider.
Automatically hides KLHThreatMeter if you are not in a raid or a party.

## Installation
1. Close any instance of WoW
2. Download **[KTM Auto Hider Zip file](https://github.com/Linae-Kronos/KTMAutoHider/archive/master.zip)**
3. Extract the zip file wherever you want
4. Copy the folder "KTMAutoHider" to Wow_Folder\Interface\AddOns
5. This is what you should have on character selection screen :

![ktmautohider](https://cloud.githubusercontent.com/assets/24671466/24856570/7bf1b654-1de5-11e7-9e0a-6d387c816475.png)

## Commands
```
/ktmah                List of useful commands
/ktmah party          Enable/Disable or disable KTM while in party
```

## Credits
The original author addon (unknown)
[Shagu](https://github.com/shagu/pfUI) for the Readme format