_____________________________________________________________________________________

AceGUI

Author:   Turan & Kaelten (kaelten@gmail.com)
Version:  0.090
Release:  12/04/2005
Website:  http://www.wowace.com
_____________________________________________________________________________________


AceGUI is a toolkit for creating and working with GUI components.

_____________________________________________________________________________________

FEATURES
_____________________________________________________________________________________

- Creates an object model XML objects so they are more easily manipulated.
- Default templates.
- A replacement dropdown template that implements a scrollbox and isn't limited to
  32 elements in the list.

_____________________________________________________________________________________

VERSION HISTORY
_____________________________________________________________________________________

[2005-12-04] 0.090
- Enhanced support for FontStrings
- Dropdown bug fixed
- Added more events to several controls
- Revereted version number down to 0.090
- Added support for ClearAllPoints to be done before anchors are applied

[2005-10-09] 0.100
- Test release
