-- This statement will load any translation that is present or default to English.
if( not ace:LoadTranslation("AceGUI") ) then

ACEGUI_NAME          = "AceGUI"
ACEGUI_DESCRIPTION   = "Tools for building graphical elements."

end
