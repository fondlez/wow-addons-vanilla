
--[[--------------------------------------------------------------------------------
  Class Definition
-----------------------------------------------------------------------------------]]

AceGUIDropDownMenuClass = AceCoreClass:new({
    menus   = {
        AceGUIDropDownMenu1,
        AceGUIDropDownMenu2,
        AceGUIDropDownMenu3
    }
})

function AceGUIDropDownMenuClass: