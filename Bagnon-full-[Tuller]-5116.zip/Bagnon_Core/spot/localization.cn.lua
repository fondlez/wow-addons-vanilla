﻿--[[
	Bagnon Spot's localization file
--]]

if ( GetLocale() == "zhCN" ) then
	BAGNON_SPOT_TOOLTIP = "<双击>进行搜索";
end