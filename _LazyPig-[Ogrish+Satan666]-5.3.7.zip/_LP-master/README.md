#_LazyPig Wow 1.12.1 

This mod is mostly for lazy people.
Some of the addon's functions may not work if you're using not en/us localized client.
To open configuration menu type /lp

Addons with similar functionality you don't need anymore
- Auto Profit
- Ez Dismount
- Automaton
- Quick Loot
- Block Salvation

## Keybindings and Key Combinations explained 


**IMPROVED RIGHT CLICK** - Enable this functionality by selecting checkbox from the menu
- RIGHT CLICK ON ITEM
  - Drag and Drop Item into Mail, Trade, Auction Window
- ALT + RIGHT CLICK ON ITEM
  - Search Auction House for selected item

**CONFIGURABLE KEY BINDINGS** - You may bind any action from the list below using standard game Key Binding menu
- Logout(default is alt+shift+ctrl)
- Reload UI
- Stuck
- Target WSG FC/Duel Request-Cancel
- Drop WSG Flag/Remove Slow Fall Buff

**SPECIAL KEY COMBINATIONS** - Enable this functionality by selecting checkbox from the menu
- CTRL+SHIFT
  - follow player(if friendly player targeted)
- ALT+SHIFT
  - inspect player
  - bid auction(if auction browse frame is open and item selected)
- ALT+CTRL
  - send mail(if item is attached to the mail)
  - create auction(if auction create frame is open and item attached)
  - buy auction(if auction browse frame is open and item selected)
  - confirm pop-up window(select yes button)
  - initiate-accept trade(if friendly player targeted)

**EASY SPLIT MERGE** - Enable this functionality by selecting checkbox from the menu
- Press Shift + Right Click on stacked item once to enable splitting mode. Set output number by using alt(inscrease) or ctrl(decrease). Afterwards press Shift+Right Click to split stack
- By opening send mail or auction sell window, item splitter will activate itself

**GOSSIP AUTOPROCESSING** - Enable this functionality by selecting checkbox from the menu
- by pressing Shift + Right Click on NPC it will automatically process single choice dialog windows

**NON CONFIGURABLE ENHANCEMENTS** - This functionality is permanently enabled
- Hold Shift Key while Merchant's window is open(Grey Items Sell/Repair)
- Hold Shift Key and finish quest once to record steps while interacting with quest NPC(Repeatable Quest Auto-Complete)
- Hold Alt Key to Pickup/Complete quests(Quest Auto-PickUp/Auto-Complete)

*[Big thanks to mrmr for improving addon's GUI](https://github.com/rsheep)*
