-- Header
ACCLOC_TITLE		=	"Accountant";
ACCLOC_TOT_IN		=	"Total Incomings";
ACCLOC_TOT_OUT		=	"Total Outgoings";
ACCLOC_NET			=	"Net Profit / Loss";
ACCLOC_NETLOSS		=	"Net Loss";
ACCLOC_NETPROF		=	"Net Profit";
ACCLOC_SOURCE		=	"Source";
ACCLOC_IN			=	"Incomings";
ACCLOC_OUT			=	"Outgoings";
ACCLOC_WEEKSTART	=	"Week Start";
ACCLOC_SUM			=	"Sum Total";
ACCLOC_CHAR			=	"Character";
ACCLOC_MONEY		=	"Money";
ACCLOC_UPDATED		=	"Updated";

-- Section Labels
ACCLOC_LOOT			=	"Loot";
ACCLOC_QUEST		=	"Quest Rewards";
ACCLOC_MERCH		=	"Merchants";
ACCLOC_TRADE		=	"Trade Window";
ACCLOC_MAIL			=	"Mail";
ACCLOC_TRAIN		=	"Training Costs";
ACCLOC_TAXI			=	"Taxi Fares";
ACCLOC_OTHER		=	"Unknown";
ACCLOC_REPAIR		=	"Repair Costs";
ACCLOC_AUC			=	"Auction House";

-- Buttons
ACCLOC_RESET		=	"Reset";
ACCLOC_OPTBUT		=	"Options";
ACCLOC_EXIT			=	"Exit";

-- Tabs
ACCLOC_SESS			=	"Session";
ACCLOC_DAY			=	"Day";
ACCLOC_WEEK			=	"Week";
ACCLOC_TOTAL		=	"Total";
ACCLOC_CHARS		=	"All Chars";

-- Options
ACCLOC_OPTS			=	"Accountant Options";
ACCLOC_MINIBUT		=	"Show Minimap Button";
ACCLOC_BUTPOS		=	"Minimap Button Position";
ACCLOC_STARTWEEK	=	"Start of Week";
ACCLOC_WD_SUN		=	"Sunday";
ACCLOC_WD_MON		=	"Monday";
ACCLOC_WD_TUE		=	"Tuesday";
ACCLOC_WD_WED		=	"Wednesday";
ACCLOC_WD_THU		=	"Thursday";
ACCLOC_WD_FRI		=	"Friday";
ACCLOC_WD_SAT		=	"Saturday";
ACCLOC_DONE			=	"Done";

-- Misc
ACCLOC_RESET_CONF	=	"Are you sure you want to reset the";
ACCLOC_NEWPROFILE	=	"New Accountant profile created for";
ACCLOC_LOADPROFILE	=	"Loaded Accountant Profile for";
ACCLOC_LOADED		=	"Loaded";

-- Key Bindings headers
BINDING_HEADER_ACCOUNTANT	=	"Accountant";
BINDING_NAME_ACCOUNTANTTOG	=	"Toggle Accountant";


-- Locale specific translations for the German client
-- by iKArus / 09-02-2005

if (GetLocale() == "deDE") then

-- Header
ACCLOC_TITLE = "Accountant";
ACCLOC_TOT_IN = "Alle Eing\195\164nge";
ACCLOC_TOT_OUT = "Alle Ausg\195\164nge";
ACCLOC_NET = "Netto Profit / Verlust";
ACCLOC_NETLOSS = "Netto Verlust";
ACCLOC_NETPROF = "Netto Profit";
ACCLOC_SOURCE = "Quelle";
ACCLOC_IN = "Eing\195\164nge";
ACCLOC_OUT = "Ausg\195\164nge";
ACCLOC_WEEKSTART = "Wochenstart";
ACCLOC_SUM = "Totale Summe";
ACCLOC_CHAR = "Charakter";
ACCLOC_MONEY = "Geld";
ACCLOC_UPDATED = "Aktualisiert";

-- Section Labels
ACCLOC_LOOT = "Beute";
ACCLOC_QUEST = "Questbelohnungen";
ACCLOC_MERCH = "H\195\164ndler";
ACCLOC_TRADE = "Handelsfenster";
ACCLOC_MAIL = "Post";
ACCLOC_TRAIN = "Trainingskosten";
ACCLOC_TAXI = "Reisekosten";
ACCLOC_OTHER = "Unbekannt";
ACCLOC_REPAIR = "Reperaturkosten";
ACCLOC_AUC = "Auktionshaus";

-- Buttons
ACCLOC_RESET = "Reset";
ACCLOC_OPTBUT = "Optionen";
ACCLOC_EXIT = "Ende";

-- Tabs
ACCLOC_SESS = "Sitzung";
ACCLOC_DAY = "Tag";
ACCLOC_WEEK = "Woche";
ACCLOC_TOTAL = "Summe";
ACCLOC_CHARS = "Alle";

-- Options
ACCLOC_OPTS = "Accountant Optionen";
ACCLOC_MINIBUT = "Zeige Minimapbutton";
ACCLOC_BUTPOS = "Minimap Button Position";
ACCLOC_STARTWEEK = "Wochenstart";
ACCLOC_WD_SUN = "Sonntag";
ACCLOC_WD_MON = "Montag";
ACCLOC_WD_TUE = "Dienstag";
ACCLOC_WD_WED = "Mittwoch";
ACCLOC_WD_THU = "Donnerstag";
ACCLOC_WD_FRI = "Freitag";
ACCLOC_WD_SAT = "Samstag";
ACCLOC_DONE = "Fertig";

-- Misc
ACCLOC_RESET_CONF = "Wirklich zur\195\188cksetzen den";
ACCLOC_NEWPROFILE = "Neues Accountantprofil erstellt f\195\188r";
ACCLOC_LOADPROFILE = "Accountantprofil geladen f\195\188r";
ACCLOC_LOADED = "Geladen";

-- Key Bindings headers
BINDING_HEADER_ACCOUNTANT = "Accountant";
BINDING_NAME_ACCOUNTANTTOG = "Accountant hin- und herschalten";

end 

-- FR Translation, thanks to Thi0u

if (GetLocale() == "frFR") then

-- Header
ACCLOC_TITLE		=	"Accountant";
ACCLOC_TOT_IN		=	"Rentr\195\169es Totales";
ACCLOC_TOT_OUT		=	"D\195\169penses Totales";
ACCLOC_NET			=	"B\195\169n\195\169fices/Pertes Nettes";
ACCLOC_NETLOSS		=	"Pertes Nettes ";
ACCLOC_NETPROF		=	"B\195\169n\195\169fices Nets";
ACCLOC_SOURCE		=	"Sources";
ACCLOC_IN			=	"Rentr\195\169es";
ACCLOC_OUT			=	"D\195\169penses";
ACCLOC_WEEKSTART	=	"D\195\169but de Semaine";
ACCLOC_SUM			=	"Somme Totale";
ACCLOC_CHAR			=	"Personnage";
ACCLOC_MONEY		=	"Argent";
ACCLOC_UPDATED		=	"Mis � jour";

-- Section Labels
ACCLOC_LOOT			=	"Ramass\195\169";
ACCLOC_QUEST		=	"R\195\169compense Qu\195\170tes";
ACCLOC_MERCH		=	"Marchands";
ACCLOC_TRADE		=	"Fen\195\170tre d'Echange";
ACCLOC_MAIL			=	"Courrier";
ACCLOC_TRAIN		=	"Co\195\187t Entra\195\174nement";
ACCLOC_TAXI			=	"Prix du Taxi";
ACCLOC_OTHER		=	"Inconnu";
ACCLOC_REPAIR		=	"Co\195\187t R\195\169paration";
ACCLOC_AUC			=	"Hotel des Ventes";

-- Buttons
ACCLOC_RESET		=	"Reset";
ACCLOC_OPTBUT		=	"Options";
ACCLOC_EXIT			=	"Exit";

-- Tabs
ACCLOC_SESS			=	"Session";
ACCLOC_DAY			=	"Jour";
ACCLOC_WEEK			=	"Semaine";
ACCLOC_TOTAL		=	"Total";
ACCLOC_CHARS		=	"Persos";

-- Options
ACCLOC_OPTS			=	"Accountant Options";
ACCLOC_MINIBUT		=	"Afficher le Bouton de la Minimap";
ACCLOC_BUTPOS		=	"Position du bouton de la Minimap";
ACCLOC_STARTWEEK	=	"D\195\169but de Semaine";
ACCLOC_WD_SUN		=	"Dimanche";
ACCLOC_WD_MON		=	"Lundi";
ACCLOC_WD_TUE		=	"Mardi";
ACCLOC_WD_WED		=	"Mercredi";
ACCLOC_WD_THU		=	"Jeudi";
ACCLOC_WD_FRI		=	"Vendredi";
ACCLOC_WD_SAT		=	"Samedi";
ACCLOC_DONE			=	"Done";

-- Misc
ACCLOC_RESET_CONF	=	"Es-tu sur de vouloir r\195\169initialiser la";
ACCLOC_NEWPROFILE	=	"Nouveau profil Accountant cr\195\169\195\169 pour";
ACCLOC_LOADPROFILE	=	"Loaded Accountant Profile for";
ACCLOC_LOADED		=	"Charg\195\169";

-- Key Bindings headers
BINDING_HEADER_ACCOUNTANT	=	"Accountant";
BINDING_NAME_ACCOUNTANTTOG	=	"Afficher Accountant";

end



if (GetLocale() == "zhCN") then
--------------------------------------------------------------------------------
-- Header
ACCLOC_TITLE = "\230\148\182\230\148\175\231\187\159\232\174\161 ";
ACCLOC_TOT_IN = "\230\128\187\230\148\182\229\133\165 ";
ACCLOC_TOT_OUT = "\230\128\187\230\148\175\229\135\186 ";
ACCLOC_NET = "\230\156\128\231\187\136\231\155\136\229\136\169/\228\186\143\230\141\159 ";
ACCLOC_NETLOSS = "\230\156\128\231\187\136\228\186\143\230\141\159 ";
ACCLOC_NETPROF = "\230\156\128\231\187\136\231\155\136\229\136\169 ";
ACCLOC_SOURCE = "\230\157\165\230\186\144 ";
ACCLOC_IN = "\230\148\182\229\133\165 ";
ACCLOC_OUT = "\230\148\175\229\135\186 ";
ACCLOC_WEEKSTART = "\228\184\128\229\145\168\232\181\183\229\167\139 ";
ACCLOC_SUM = "\228\184\128\229\145\168\232\181\183\229\167\139 ";
ACCLOC_CHAR = "\232\180\166\229\143\183 ";
ACCLOC_MONEY = "\233\135\145\233\146\177 ";
ACCLOC_UPDATED = "\230\156\128\229\144\142\230\155\180\230\150\176 ";

-- Section Labels
ACCLOC_LOOT = "\230\139\190\229\143\150 ";
ACCLOC_QUEST = "\228\187\187\229\138\161\233\133\172\233\135\145 ";
ACCLOC_MERCH = "\229\135\186\229\148\174 ";
ACCLOC_TRADE = "\228\186\164\230\152\147 ";
ACCLOC_MAIL = "\233\130\174\228\187\182 ";
ACCLOC_TRAIN = "\232\174\173\231\187\131\230\148\175\229\135\186 ";
ACCLOC_TAXI = "\230\156\186\231\165\168 ";
ACCLOC_OTHER = "\230\156\170\231\159\165 ";
ACCLOC_REPAIR = "\228\191\174\231\144\134\232\180\185\231\148\168 ";
ACCLOC_AUC = "\230\139\141\229\141\150\232\161\140 ";

-- Buttons
ACCLOC_RESET = "\233\135\141\231\189\174 ";
ACCLOC_OPTBUT = "\233\128\137\233\161\185 ";
ACCLOC_EXIT = "\233\128\128\229\135\186 ";

-- Tabs
ACCLOC_SESS = "\230\156\172\233\152\182\230\174\181 ";
ACCLOC_DAY = "\230\156\172\230\151\165 ";
ACCLOC_WEEK = "\230\156\172\229\145\168 ";
ACCLOC_TOTAL = "\229\144\136\232\174\161 ";
ACCLOC_CHARS = "\232\180\166\229\143\183 ";

-- Options
ACCLOC_OPTS = "\230\148\182\230\148\175\231\187\159\232\174\161\233\128\137\233\161\185 ";
ACCLOC_MINIBUT = "\229\156\168\232\191\183\228\189\160\229\156\176\229\155\190\230\151\129\230\152\190\231\164\186\230\140\137\233\146\174 ";
ACCLOC_BUTPOS = "\232\191\183\228\189\160\229\156\176\229\155\190\230\140\137\233\146\174\228\189\141\231\189\174 ";
ACCLOC_STARTWEEK = "\228\184\128\229\145\168\232\181\183\229\167\139\230\151\165 ";
ACCLOC_WD_SUN = "\230\152\159\230\156\159\230\151\165 ";
ACCLOC_WD_MON = "\230\152\159\230\156\159\228\184\128 ";
ACCLOC_WD_TUE = "\230\152\159\230\156\159\228\186\140 ";
ACCLOC_WD_WED = "\230\152\159\230\156\159\228\184\137 ";
ACCLOC_WD_THU = "\230\152\159\230\156\159\229\155\155 ";
ACCLOC_WD_FRI = "\230\152\159\230\156\159\228\186\148 ";
ACCLOC_WD_SAT = "\230\152\159\230\156\159\229\133\173 ";
ACCLOC_DONE = "\229\174\140\230\136\144 ";

-- Misc
ACCLOC_RESET_CONF = "\228\189\160\231\161\174\229\174\154\232\166\129\233\135\141\231\189\174 ";
ACCLOC_NEWPROFILE = "\230\150\176\229\187\186\230\148\182\230\148\175\231\187\159\232\174\161\232\180\166\230\136\183\239\188\154 ";
ACCLOC_LOADPROFILE = "\232\189\189\229\133\165\230\148\182\230\148\175\231\187\159\232\174\161\232\180\166\230\136\183\239\188\154 ";
ACCLOC_LOADED = "\229\183\178\232\189\189\229\133\165 ...";

-- Key Bindings headers
BINDING_HEADER_ACCOUNTANT = "\230\148\182\230\148\175\231\187\159\232\174\161 ";
BINDING_NAME_ACCOUNTANTTOG = "\229\188\128\229\144\175\230\148\182\230\148\175\231\187\159\232\174\161 "; 

end
