ACCOUNTANT_BUTTON_TOOLTIP = "Toggle Accountant";

function AccountantButton_OnClick()
	if AccountantFrame:IsVisible() then
		HideUIPanel(AccountantFrame);
	else
		ShowUIPanel(AccountantFrame);
	end
	
end

function AccountantButton_Init()
	Accountant_Player = UnitName("player");
	Accountant_Realm = GetCVar("realmName");
	Accountant_Faction = UnitFactionGroup("Player");
	
	if(Accountant_SaveData[Accountant_Realm][Accountant_Faction][Accountant_Player]["options"].showbutton) then
		AccountantButtonFrame:Show();
	else
		AccountantButtonFrame:Hide();
	end
end

function AccountantButton_Toggle()
	Accountant_Player = UnitName("player");
	Accountant_Realm = GetCVar("realmName");
	Accountant_Faction = UnitFactionGroup("Player");
	if(AccountantButtonFrame:IsVisible()) then
		AccountantButtonFrame:Hide();
		Accountant_SaveData[Accountant_Realm][Accountant_Faction][Accountant_Player]["options"].showbutton = false;
	else
		AccountantButtonFrame:Show();
		Accountant_SaveData[Accountant_Realm][Accountant_Faction][Accountant_Player]["options"].showbutton = true;
	end
end

function AccountantButton_UpdatePosition(newposition)
	Accountant_Player = UnitName("player");
	Accountant_Realm = GetCVar("realmName");
	Accountant_Faction = UnitFactionGroup("Player");
	Accountant_SaveData[Accountant_Realm][Accountant_Faction][Accountant_Player]["options"].buttonpos =newposition;
	AccountantButtonFrame:SetPoint(
		"TOPLEFT",
		"Minimap",
		"TOPLEFT",
		55 - (75 * cos(Accountant_SaveData[Accountant_Realm][Accountant_Faction][Accountant_Player]["options"].buttonpos)),
		(75 * sin(Accountant_SaveData[Accountant_Realm][Accountant_Faction][Accountant_Player]["options"].buttonpos)) - 55
	);
end