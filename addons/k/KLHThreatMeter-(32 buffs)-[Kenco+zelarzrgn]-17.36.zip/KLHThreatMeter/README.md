# KLHThreatMeter 17.36

Compared to previous versions of KTM, this versions checks  over 32 possible buffs rather than only 16, increasing the chance that buffs like salvation are detected. It is possible to have more than 32 buffs in the 1.12 client. As long as salvation is among the first 32, it should always be accounted for.

## Installation Instructions

1. Download and extract this file https://github.com/zelazrgn/KLHThreatMeter/archive/master.zip
2. Unzip the file.
3. Delete the current `KLHThreatMeter` folder inside `Interface/Addons` if it exists.
4. Move `KLHThreatMeter-master` into `Interface/Addons`
5. Rename `KLHThreatMeter-master` to `KLHThreatMeter`
