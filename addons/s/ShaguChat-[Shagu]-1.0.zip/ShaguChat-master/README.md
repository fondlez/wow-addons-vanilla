# ShaguChat

This addon is a chat blocker and notifier. It hides and/or highlights chat messages with specific keywords. Type `/sc` or `/shaguchat` for usage info. Highlighted messages will be colored and also printed to the default Error Frame in the center of the screen

![preview](https://raw.githubusercontent.com/shagu/ShaguAddons/master/_img/ShaguChat/fullscreen.jpg)

## Installation
1. Download **[Latest Version](https://gitlab.com/shagu/ShaguChat/-/archive/master/ShaguChat-master.zip)**
2. Unpack the Zip file
3. Rename the folder "ShaguChat-master" to "ShaguChat"
4. Copy "ShaguChat" into Wow-Directory\Interface\AddOns
5. Restart Wow

## Commands

* **/shaguchat**
* **/sc**