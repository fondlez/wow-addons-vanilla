# ShaguInventory

Started as a fork of an abandoned project called "InventoryCounter". It shows the quantity of items in your inventory over all charactes on the same account. The XML File was removed and completely replaced by Lua Code. But basically there are only optical changes done like dual pane tooltip infos. Sadly the original code can't be accessed anymore as the forum where it has been hosted changed to another software.

This addon shows the count of items you have on all chars (accountwide) as a tooltip info.

![preview](https://raw.githubusercontent.com/shagu/ShaguAddons/master/_img/ShaguInventory/tooltip.jpg)

## Installation
1. Download **[Latest Version](https://gitlab.com/shagu/ShaguInventory/-/archive/master/ShaguInventory-master.zip)**
2. Unpack the Zip file
3. Rename the folder "ShaguInventory-master" to "ShaguInventory"
4. Copy "ShaguInventory" into Wow-Directory\Interface\AddOns
5. Restart Wow