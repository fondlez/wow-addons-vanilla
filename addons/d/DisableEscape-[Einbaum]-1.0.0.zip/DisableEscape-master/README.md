# DisableEscape

Prevents the escape button from cancelling *party invites* and *summons*.
