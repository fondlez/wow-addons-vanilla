
for _, a in {"PARTY_INVITE", "CONFIRM_SUMMON"} do
	StaticPopupDialogs[a].hideOnEscape = nil
end