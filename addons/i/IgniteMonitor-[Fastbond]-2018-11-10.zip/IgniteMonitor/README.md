# IgniteMonitor
World of Warcraft 1.12.1 Addon for tracking Ignites

Stopped developing this addon as the people who had requested it quit.  
If you find it useful and are able to provide feedback let me know and I may continue working on it.
