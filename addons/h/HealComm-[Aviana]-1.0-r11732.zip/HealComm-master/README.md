# HealComm

![HealComm](https://i.imgur.com/qJLv1m5.png)

## Visual representation of incoming heals.
Created by:[Aviana](https://github.com/Aviana)