-------------------
-- All used NPCs --
-------------------
MTSLDATA["objects"] = {
	{
		id = 164869,
		name = "Spectral Chalice",
		zone = "",
	},
	{
		id = 180503,
		name = "Sandy Cookbook",
		zone = "Silithus",
		location = {
			x = "37.94",
			y = "45.31",
		},
	},
	{
		id = 180794,
		name = "Journal of Jandice Barov",
		zone = "Scholomance",
		location = {
			x = "28.93",
			y = "17.03",
		},
	},
}
