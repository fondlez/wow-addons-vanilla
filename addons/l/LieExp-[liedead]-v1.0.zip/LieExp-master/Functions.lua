--[[
    Functions.lua
    LieExp.lua event handlers fire these functions
--]]

-- Init function, called during VARIABLES_LOADED
function LieExp:Init()
    SLASH_LIEEXP1 = "/lieexp";
    SlashCmdList["LIEEXP"] = function(msg) OnSlashCmd(msg); end

    if(LieExp_settings == nil) then LieExp:ResetSettings(); end
    if(LieExp_session == nil) then LieExp:ResetSession(); end

    -- The settings initialise as nil, so if they're not nil, they're saved variables
    if(LieExp_settings.xPos) then
        this:ClearAllPoints();
        this:SetPoint("BOTTOMLEFT", LieExp_settings.xPos, LieExp_settings.yPos);
    end
    if(LieExp_settings.barColor) then
        r, g, b = LieExp:HexToRGB(LieExp_settings.barColor);
        LieExp_EXPSTATUSBAR:SetStatusBarColor(r, g, b, 1);
    end
    if(LieExp_settings.textColor) then
        r, g, b = LieExp:HexToRGB(LieExp_settings.textColor);
        LieExp_EXPSTATUSTEXT:SetTextColor(r, g, b, 1);
    end
    -- Set the width and height independently in case one is changed but not the other
    if(LieExp_settings.xSize) then
        this:SetWidth(LieExp_settings.xSize);
        LieExp_EXPSTATUSBAR:SetWidth(LieExp_settings.xSize);
        LieExp_EXPBACKDROP:SetWidth(LieExp_settings.xSize);
    end
    if(LieExp_settings.ySize) then
        this:SetHeight(LieExp_settings.ySize);
        LieExp_EXPSTATUSBAR:SetHeight(LieExp_settings.ySize);
        LieExp_EXPBACKDROP:SetHeight(LieExp_settings.ySize);
    end

    -- Show or hide text
    if(LieExp_settings.toggleText) then LieExp_EXPSTATUSTEXT:Show(); else LieExp_EXPSTATUSTEXT:Hide(); end

    -- Show or hide bar
    if(LieExp_settings.toggleBar) then
        this:Hide();
        LieExp_EXPBACKDROP:Hide();
    else
        this:Show();
        LieExp_EXPBACKDROP:Show();
    end
end

-- Callback for the SlashCmdList
function OnSlashCmd(msg)
    local arg1, arg2;
    arg2pos = strfind(msg, "%s");
    if(not arg2pos) then 
        arg1 = msg;
        arg2 = " ";
    else
        -- Split at the space and compensate with +/-1
        arg1 = strsub(msg, 1, arg2pos - 1);
        arg2 = strsub(msg, arg2pos + 1);
    end

    if(arg1 == "help") then
        DEFAULT_CHAT_FRAME:AddMessage(LieExp.UsageString);
        return;
    elseif(arg1 == "" or arg1 == "about") then
        DEFAULT_CHAT_FRAME:AddMessage(LieExp.AboutString);
        return;
    end

    if(arg1 == "start_session" and arg2 == " ") then
        DEFAULT_CHAT_FRAME:AddMessage(LieExp.StartSessionString);
        LieExp:StartSession();
        return;
    elseif(arg1 == "pause_session" and arg2 == " ") then
        DEFAULT_CHAT_FRAME:AddMessage(LieExp.PauseSessionString);
        LieExp:PauseSession();
        return;
    elseif(arg1 == "reset_session" and arg2 == " ") then
        DEFAULT_CHAT_FRAME:AddMessage(LieExp.ResetSessionString);
        LieExp:ResetSession();
        return;
    end

    if(arg1 == "toggle_rep" and arg2 == " ") then
        LieExp_settings.isTrackingRep = not LieExp_settings.isTrackingRep;
        if LieExp_settings.isTrackingRep then
            DEFAULT_CHAT_FRAME:AddMessage(LieExp.RepStringOn);
        else
            DEFAULT_CHAT_FRAME:AddMessage(LieExp.RepStringOff);
        end
        return;
    end

    if(arg1 == "reset_settings" and arg2 == " ") then
        LieExp:ResetSettings();
    
    elseif(arg1 == "toggle_bar" and arg2 == " ") then
        LieExp_settings.toggleBar = not LieExp_settings.toggleBar;

    elseif(arg1 == "set_color" and strfind(arg2, "%x%x%x%x%x")) then
        LieExp_settings.barColor = arg2;

    elseif(arg1 == "set_text_color" and strfind(arg2, "%x%x%x%x%x")) then
        LieExp_settings.textColor = arg2;

    elseif(arg1 == "toggle_text" and arg2 == " ") then
        LieExp_settings.toggleText = not LieExp_settings.toggleText;

    elseif(arg1 == "set_width" and strfind(arg2, "%d")) then
        LieExp_settings.xSize = arg2;

    elseif(arg1 == "set_height" and strfind(arg2, "%d")) then
        LieExp_settings.ySize = arg2;
    else
        DEFAULT_CHAT_FRAME:AddMessage(LieExp.InvalidString);
        return;
    end
    DEFAULT_CHAT_FRAME:AddMessage(LieExp.ReloadString);
end

function LieExp:ResetSettings()
    LieExp_settings = {
        xPos = nil,
        yPos = nil,
        xSize = 350,
        ySize = 28,
        toggleText = true,
        textColor = "ffffff",
        barColor = "1b1b1b",
        isTrackingRep = false,
        toggleBar = true
    }
end

function LieExp:UpdateExpTracker()
    local currentExp = UnitXP("player");
    local reqExp = UnitXPMax("player");

    -- Set EXP text
    LieExp_EXPSTATUSTEXT:SetText(currentExp .. "/" .. reqExp .. " (" .. LieExp:GetReadableExhaustion() .. " rested)");

    LieExp_EXPSTATUSBAR:SetMinMaxValues(min(0, currentExp), reqExp);
    LieExp_EXPSTATUSBAR:SetValue(currentExp);
end

function LieExp:UpdateRepTracker()
    for i=1, GetNumFactions() do
        local name, description, standingID, barMin, barMax, barValue, atWarWith, canToggleAtWar, isHeader, isCollapsed, isWatched = GetFactionInfo(i);
        if isWatched then
            reqRep = barMax - barMin;
            currentRep = barValue - barMin;
            LieExp_EXPSTATUSTEXT:SetText(currentRep .. "/" .. reqRep .. " (" .. name .. ")");
            LieExp_EXPSTATUSBAR:SetMinMaxValues(min(0, currentRep), reqRep);
            LieExp_EXPSTATUSBAR:SetValue(currentRep);
        end
    end
end

-- Tooltip for mousing over the bar
function LieExp:ShowExpToolTip()
    local sessionTime = LieExp:GetSessionTime();
    local sessionActiveText;
    if(LieExp:IsSessionActive()) then
        sessionActiveText = "Session is active";
    else
        sessionActiveText = "Session is inactive";
    end
    GameTooltip:SetOwner(this, "ANCHOR_RIGHT");
    GameTooltip:AddLine("LieExp");
    GameTooltip:AddLine("Current level: " .. UnitLevel("player"));
    GameTooltip:AddLine("Percentage through current level: " .. LieExp:GetExpPercentageString());
    GameTooltip:AddLine("Rested exp: " .. LieExp:GetReadableExhaustion());
    GameTooltip:AddLine(sessionActiveText);
    GameTooltip:AddLine("Session Time: " .. LieExp:SecondsToClockFormat(sessionTime));
    GameTooltip:AddLine("Exp gained this session: " .. LieExp_session.expGained);
    GameTooltip:AddLine("Exp per minute: " .. LieExp:GetExpPerMinString());
    GameTooltip:AddLine("Exp per hour: " .. LieExp:GetExpPerHourString());
    GameTooltip:Show();
end

-- Helper functions

function LieExp:SecondsToClockFormat(secondsElapsed)
    if(secondsElapsed == 0) then
        return "00.00.00";
    else
        hours = string.format("%02.f", math.floor(secondsElapsed/LieExp.HOUR));
        minutes = string.format("%02.f", math.floor((secondsElapsed/LieExp.MINUTE) - (hours*LieExp.MINUTE)));
        seconds = string.format("%02.f", math.floor(secondsElapsed - (hours*LieExp.HOUR) - (minutes*LieExp.MINUTE)));
        return hours .. "." .. minutes .. "." .. seconds;
    end
end

function LieExp:GetReadableExhaustion()
    local xpExh = GetXPExhaustion();
    if xpExh == nil then return 0; end
    return xpExh;
end

function LieExp:HexToRGB(hex)
    hex = gsub(hex, "#", "");
    local r = tonumber(strsub(hex, 1, 2), 16);
    local g = tonumber(strsub(hex, 3, 4), 16);
    local b = tonumber(strsub(hex, 5, 6), 16);
    return r/255, g/255, b/255;
  end