--[[
    Globals.lua
    Provides global variables to the addon
--]]

LieExp = {};
LieExp.version = "v1.0"
LieExp.email = "liescorpse@gmail.com"

LieExp.MINUTE = 60;
LieExp.HOUR = 3600;

-- Strings for chat
LieExp.UsageString = [[LieExp Usage:
|cFFFFFF00/lieexp start_session |r- Starts tracking time and exp gained during the session
|cFFFFFF00/lieexp pause_session |r- Pauses the session tracking and saves your exp gained and time played (do this before logging out)
|cFFFFFF00/lieexp reset_session |r- Stops the session tracking and resets it to zero
|CFFFFFF00/lieexp toggle_rep |r- Toggles reputation tracking on or off (Open the reputation pane and click "Show as experience bar" on a reputation to track)
|CFFFFFF00/lieexp toggle_bar |r- Toggles the custom bar off and on
|cFFFFFF00/lieexp reset_settings |r- Resets all customisation settings to defaults
|cFFFFFF00/lieexp set_color [hex color code] |r- Sets the bar color to the specified hex color, e.g FFFFFF (white)
|cFFFFFF00/lieexp set_text_color [hex color code] |r- Sets the text color on the bar to the specified hex color
|cFFFFFF00/lieexp toggle_text |r- Toggles text off and on
|cFFFFFF00/lieexp set_width [num] |r- Sets the width of the bar to the specified num (default 350)
|cFFFFFF00/lieexp set_height [num] |r- Sets the height of the bar to the specified num (default 28)
|cFFFFFF00/lieexp help |r- Displays this 
|cFFFFFF00/lieexp about |r- Displays information about LieExp ]]

LieExp.StartSessionString = [[|cFFFFFF00LieExp:|r Started Session]]
LieExp.PauseSessionString = [[|cFFFFFF00LieExp:|r Paused Session]]
LieExp.ResetSessionString = [[|CFFFFFF00LieExp:|r Reset Session]]
LieExp.RepStringOn = [[|cFFFFFF00LieExp:|r Toggled reputation tracking on. (Updates next Rep change or /console reloadui)]]
LieExp.RepStringOff = [[|cFFFFFF00LieExp:|r Toggled reputation tracking on. off. (Updates next Exp gain or /console reloadui)]]

LieExp.InvalidString = [["Invalid command, please type |cFFFFFF00'/lieexp help'|r for help"]]

LieExp.ReloadString = [[|cFFFFFF00LieExp:|r Done, please run |cFFFFFF00/console reloadui |rto set your changes.]]
LieExp.AboutString = [[|cFFFFFF00LieExp|r ]] .. LieExp.version .. [[: Adds an experience p/hour p/minute tracking tooltip and a simple customisable bar
Contact email: |cFFFFFF00 ]] .. LieExp.email .. [[|r
Type |cFFFFFF00'/lieexp help'|r for usage]]

-- Saved variables
LieExp_settings = nil;
LieExp_session = nil;