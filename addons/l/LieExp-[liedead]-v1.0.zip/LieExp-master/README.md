# LieExp v1.0

###### Made for Vanilla World of Warcraft - patch 1.12

Experience p/hour p/minute session tracking and customisable experience bar

### Features

* Sessions tracking time played and experienced gained, saved per character

* Mouseover tooltip information about your session

* Simple, customisable experience bar that can be hidden

* Configurable position, colours, size, switch to track your current watched reputation


### Screenshots

###### Default tooltip

![Screenshot of the addon](Screenshots/sc1.png)

###### Custom bar

![Screenshot of the addon](Screenshots/sc2.png)

### Usage

```/lieexp [command]```

Command | Result
------------ | -------------
start_session | Starts tracking time and exp gained during the session
pause_session | Pauses the session tracking and saves your exp gained and time played (do this before logging out)
reset_session | Stops the session tracking and resets it to zero
toggle_rep | Toggles reputation tracking on or off (Open the reputation pane and click "Show as experience bar" on a reputation to track)
toggle_bar | Toggles the custom bar off and on
reset_settings | Resets all customisation settings to defaults
set_color [hex color code] | Sets the bar color to the specified hex color (e.g: 'ffffff' - white)
set_text_color [hex color code] | Sets the text color on the bar to the specified hex color (e.g: 'ffffff' - white)
toggle_text | Toggles text off and on
set_width [num] | Sets the width of the bar to the specified num (default 350)
set_height [num] | Sets the height of the bar to the specified num (default 28)
help | Displays this 
about | Displays information about LieExp

## Download

https://github.com/liedead/LieExp/releases

Download the zip file from the latest release and drag the folder LieExp into Interface/Addons
