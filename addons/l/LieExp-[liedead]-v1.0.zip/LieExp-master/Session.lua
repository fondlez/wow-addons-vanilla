-- Session functions

function LieExp:StartSession()
    if(LieExp_session.isPaused) then
        LieExp_session.isPaused = false;
        -- Adds the gap between pause and unpause to the start time
        LieExp_session.startTime = LieExp_session.startTime + (GetTime() - LieExp_session.pauseTime);
        LieExp_session.baseExp = UnitXP("player");
    else
        LieExp_session.startTime = GetTime();
        LieExp_session.expGained = 0;
        LieExp_session.baseExp = UnitXP("player");
    end
end

function LieExp:PauseSession()
    if(not LieExp:IsSessionActive()) then return; end
    LieExp_session.pauseTime = GetTime();
    -- Rare edge case: player manages to pause the session after PLAYER_LEVEL_UP fires but before PLAYER_XP_UPDATE
    -- In this case the next PLAYER_XP_UPDATE (UpdateSession()) needs to handle it as if the player has not leveled up
    --  because baseExp is set to the player's current exp when the session is started again anyway
    LieExp_session.playerLeveledUp = false;
    LieExp_session.isPaused = true;
end

function LieExp:ResetSession()
    LieExp_session = {
        startTime = 0,
        expGained = 0,
        baseExp = UnitXP("player"),
        playerLeveledUp = false,
        isPaused = false
    };
end

function LieExp:UpdateSession()
    local currentExp = UnitXP("player");
    if(LieExp_session.playerLeveledUp) then
        -- If the player has leveled up, this is fired right after as the "real" experience change
        -- PLAYER_LEVEL_UP event adds the exp needed to level to the session tracker, this adds the exp "left over"
        LieExp_session.expGained = LieExp_session.expGained + currentExp;
        LieExp_session.playerLeveledUp = false;
    else
        LieExp_session.expGained = LieExp_session.expGained + (currentExp - LieExp_session.baseExp);
    end
    LieExp_session.baseExp = currentExp;
end

function LieExp:HandleSessionLevelUp()
    local currentExp = UnitXP("player");
    local maxExp = UnitXPMax("player");

    -- This adds the experience the player needed in order to level up
    LieExp_session.expGained = LieExp_session.expGained + (maxExp - currentExp);
    LieExp_session.playerLeveledUp = true;
end

function LieExp:IsSessionActive()
    return (LieExp_session.startTime ~= 0 and not LieExp_session.isPaused);
end

function LieExp:GetExpPerMinString()
    if(LieExp_session.startTime == 0) then return '-'; end
    return string.format("%.1f", LieExp_session.expGained/(LieExp:GetSessionTime() / LieExp.MINUTE));
end

function LieExp:GetExpPerHourString()
    if(LieExp_session.startTime == 0) then return '-'; end
    return string.format("%.1f", LieExp_session.expGained/(LieExp:GetSessionTime() / LieExp.HOUR));
end

function LieExp:GetExpPercentageString()
    if(UnitXPMax("player") == 0) then return '-'; end
    return string.format("%.2f", (UnitXP("player")/UnitXPMax("player")) * 100) .. "%";
end

function LieExp:GetSessionTime()
    if(LieExp_session.isPaused) then return (LieExp_session.pauseTime - LieExp_session.startTime); end
    if(LieExp_session.startTime == 0) then return 0; end
    return GetTime() - LieExp_session.startTime;
end
