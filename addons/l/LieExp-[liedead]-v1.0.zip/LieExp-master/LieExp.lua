--[[
    LieExp.lua
    Used by Frame XML file, handles events
--]]

-- Fired when XML bar loads
function LieExp_OnLoad()
    this:RegisterEvent("VARIABLES_LOADED");
    this:RegisterEvent("PLAYER_ENTERING_WORLD");
    this:RegisterEvent("PLAYER_LEVEL_UP");
    this:RegisterEvent("PLAYER_XP_UPDATE");
    this:RegisterEvent("UPDATE_EXHAUSTION");
    this:RegisterEvent("UPDATE_FACTION");

    -- MainMenuExpBar = Blizzard's Experience bar above the action bar
    MainMenuExpBar:SetScript("OnEnter", MainMenuExpBar_OnEnter);
end

function MainMenuExpBar_OnEnter()
    LieExp:ShowExpToolTip();
end

-- Fired when XML bar receives subscribed event
function LieExp_OnEvent(event, arg1, arg2)

    if(event == "VARIABLES_LOADED") then
        LieExp:Init();
    elseif(event == "PLAYER_ENTERING_WORLD") then
        LieExp:UpdateExpTracker();
    elseif(event == "PLAYER_LEVEL_UP" and LieExp.IsSessionActive()) then
        LieExp:HandleSessionLevelUp();
    elseif(event == "PLAYER_XP_UPDATE" and not LieExp_settings.isTrackingRep) then
        if(LieExp.IsSessionActive()) then
            LieExp:UpdateSession();
        end
        LieExp:UpdateExpTracker();
    elseif(event == "UPDATE_EXHAUSTION" and not LieExp_settings.isTrackingRep) then
        LieExp:UpdateExpTracker();
    elseif(event == "UPDATE_FACTION" and LieExp_settings.isTrackingRep) then
        LieExp:UpdateRepTracker();
    end
end

-- Fired when the mouse clicks in any capacity on the frame
function LieExp_OnMouseDown(arg1)
    if(IsShiftKeyDown() and arg1 == "LeftButton") then
        this:StartMoving();
    end
end
-- Fired when the releases a click from the frame
function LieExp_OnMouseUp(arg1)
    if(arg1 == "LeftButton") then
        this:StopMovingOrSizing();
        -- Save position of bar
        LieExp_settings.xPos = (this:GetLeft());
        LieExp_settings.yPos = (this:GetBottom());
    end
end

-- Fired when mouse enters the exp bar
function LieExp_OnEnter()
    LieExp:ShowExpToolTip();
end

-- Fired when mouse leaves the exp bar
function LieExp_OnLeave()
    GameTooltip:Hide();
end