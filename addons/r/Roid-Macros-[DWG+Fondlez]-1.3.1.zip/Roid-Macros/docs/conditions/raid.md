# raid

The condition will only fire when your target is in your raid.

## Examples

```lua
/cast [raid] Arcane Brilliance; Arcane Intellect
```

This macro will cast Arcane Brilliance when your current target is in your
raid. If your target isn't, it will cast Arcane Intellect on it instead.