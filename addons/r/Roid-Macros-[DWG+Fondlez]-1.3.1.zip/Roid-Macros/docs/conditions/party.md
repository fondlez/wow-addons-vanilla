# party

The condition will only fire when your target is in your party.

## Examples

```lua
/cast [party] Arcane Brilliance; Arcane Intellect
```

This macro will cast Arcane Brilliance when your current target is in your
party. If your target isn't, it will cast Arcane Intellect on it instead.