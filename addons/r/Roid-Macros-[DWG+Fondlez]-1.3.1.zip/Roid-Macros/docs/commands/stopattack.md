# /stopattack

`/stopattack` will make you stop attacking with your melee weapons. Spammable.

## Examples

```lua
/cast Gouge
/stopattack
```

You will cast Gouge and immediately stop attacking.
