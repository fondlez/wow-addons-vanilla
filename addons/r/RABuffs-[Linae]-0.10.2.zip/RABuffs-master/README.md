# RABuff

Improved version of RABuff. 

# Known Bugs
 
# TODO

* Add Weaponoils (wont work)
* Add Poisons (wont work)
* Add Eko

# Done

* Item-Buffs not displayed correctly
* Add Trollblood Elixir
* Add Firemight / Frostmight Elixir
* Add Frost Prot Potion
* Add Arcane Prot Potion
