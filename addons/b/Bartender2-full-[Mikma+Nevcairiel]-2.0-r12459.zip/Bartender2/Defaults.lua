BT2Defaults = {
		Extra = {},
		Bar1 = {
			Scale = 1,
			Padding = -1,
			Rows = 1,
			Alpha = 1,
	        },
		Bar2 = {
			Scale = 1,
			Padding = -1,
			Rows = 1,
			Alpha = 1,
	        },
		Bar3 = {
			Scale = 1,
			Padding = -1,
			Rows = 1,
			Alpha = 1,
	        },
		Bar4 = {
			Scale = 1,
			Padding = -1,
			Rows = 12,
			Alpha = 1,
	        },
		Bar5 = {
			Scale = 1,
			Padding = -1,
			Rows = 12,
			Alpha = 1,
	        },
		Bar6 = {
			Scale = 1,
			Padding = 0,
			Swap = false,
			Alpha = 1,
	        },
		Bar7 = {
			Scale = 1,
			Padding = 0,
			Swap = false,
			Alpha = 1,
	        },
		Bar8 = {
			Scale = 1,
			Padding = 0,
			Swap = false,
			Alpha = 1,
	        },
		Bar9 = {
			Scale = 1,
			Padding = -4,
			Swap = false,
			Alpha = 1,
	        },
		Bar10 = {
			Scale = 1,
			Padding = -1,
			Rows = 1,
			Alpha = 1,
			NoSwap = false,
		},
} 