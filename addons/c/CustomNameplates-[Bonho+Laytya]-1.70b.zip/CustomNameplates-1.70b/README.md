# CustomNameplates
Vanilla WoW Nameplate addon. Original author: Bonho, Modifications by Snelf, Lulleh, Roadblock, Laytya (me)

![CustomNameplates Screen](http://i.imgur.com/4o5Frqw.jpg)
![CustomNameplates](http://i.imgur.com/3BGqhML.jpg)
![CustomNameplates](http://i.imgur.com/AaHg6A1.jpg)

### Reminder:  
If this is the first time installing the addon and want to customize some lua options
1. rename _settings.lua to settings.lua (remove the leading underscore _ )
2. edit whatever values you want to change in settings.lua

##Changelog:

Added many things such as:
- Casting bar
- Debuffs
- Combopoints
and some small things...

Timers on debuffs will work only if u have Chronometer installed.

You can get it from  [HERE](https://github.com/laytya/Chronometer-vanilla) fixed

##Downloads:

https://github.com/laytya/CustomNameplates/releases

##Installation:

Copy dir "CustomNameplates" to your addon's dir. 
