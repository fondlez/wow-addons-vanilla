-- Version : French ( by Sasmira )
-- Last Update : 03/31/2005


if ( GetLocale() == "frFR" ) then

CT_QUESTLEVELS_MODNAME = "Niveau des Qu\195\170tes";
CT_QUESTLEVELS_SUBNAME = "ON/OFF";
CT_QUESTLEVELS_TOOLTIP = "Afficher le niveau des Qu\195\170tes dans le Journal de Qu\195\170tes.";

CT_QUESTLEVELS_ON = "<CTMod> Le niveau des Qu\195\170tes est maintenant affich\195\169 dans le Journal de Qu\195\170tes.";
CT_QUESTLEVELS_OFF = "<CTMod> Le niveau des Qu\195\170tes est maintenant cach\195\169 dans le Journal de Qu\195\170tes.";

end