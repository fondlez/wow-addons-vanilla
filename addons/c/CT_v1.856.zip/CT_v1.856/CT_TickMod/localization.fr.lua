-- Version : French ( by Sasmira )
-- Last Update : 03/31/2005


if ( GetLocale() == "frFR" ) then

CT_TICKMOD_OFF = "L\'affichage de la R\195\169g\195\169n\195\169ration des Points de Vie & Points de Mana est maintenant d\195\169sactiv\195\169.";
CT_TICKMOD_ON = "L\'affichage de la R\195\169g\195\169n\195\169ration des Points de Vie & Points de Mana est maintenant activ\195\169.";

CT_TICKMOD_MODNAME = "R\195\169g\195\169n\195\169ration";
CT_TICKMOD_SUBNAME = "ON/OFF";
CT_TICKMOD_TOOLTIP = "Affichage de la R\195\169g\195\169n\195\169ration des Points de Vie & Points de Mana.";

end