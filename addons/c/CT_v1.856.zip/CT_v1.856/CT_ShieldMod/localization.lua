CT_SHIELDMOD_MODNAME = "Shield Mod";
CT_SHIELDMOD_SUBNAME = "Save Info";
CT_SHIELDMOD_TOOLTIP = "Enable this to save damage info over sessions";

CT_SHIELDMOD_MOVABLE = "ShieldMod";