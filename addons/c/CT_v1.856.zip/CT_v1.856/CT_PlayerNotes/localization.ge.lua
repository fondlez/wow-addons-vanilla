if ( GetLocale() == "deDE" ) then
	-- Credits to Hj�rvar�r for these

	CT_PLAYERNOTES_EDITING = "Notiz f\195\188r Spieler '%s' bearbeiten.";
	CT_PLAYERNOTES_CANCEL = "Abbrechen";
	CT_PLAYERNOTES_UPDATE = "Aktualisieren";
	CT_PLAYERNOTES_EDITNOTE = "Notiz bearbeiten";
	CT_PLAYERNOTES_CLICKEDIT = "Klicken zum Bearbeiten";

end