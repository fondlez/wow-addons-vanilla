-- Version : French ( by Sasmira )
-- Last Update : 03/31/2005


if ( GetLocale() == "frFR" ) then
	CT_UFO_PARTYTEXTSIZE = "Taille du Texte";
end