CT_MP_PARTY1 = "Party member 1";
CT_MP_PARTY2 = "Party member 2";
CT_MP_PARTY3 = "Party member 3";
CT_MP_PARTY4 = "Party member 4";