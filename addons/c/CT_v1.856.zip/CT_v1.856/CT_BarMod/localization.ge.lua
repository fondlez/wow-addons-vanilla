if ( GetLocale() == "deDE" ) then
	BINDING_HEADER_CT_HOTBAR1 = "Buttons der linken Zusatzleiste";
	BINDING_NAME_CT_HOTBAR1BUTTON1 = "Button 1";
	BINDING_NAME_CT_HOTBAR1BUTTON2 = "Button 2";
	BINDING_NAME_CT_HOTBAR1BUTTON3 = "Button 3";
	BINDING_NAME_CT_HOTBAR1BUTTON4 = "Button 4";
	BINDING_NAME_CT_HOTBAR1BUTTON5 = "Button 5";
	BINDING_NAME_CT_HOTBAR1BUTTON6 = "Button 6";
	BINDING_NAME_CT_HOTBAR1BUTTON7 = "Button 7";
	BINDING_NAME_CT_HOTBAR1BUTTON8 = "Button 8";
	BINDING_NAME_CT_HOTBAR1BUTTON9 = "Button 9";
	BINDING_NAME_CT_HOTBAR1BUTTON10 = "Button 10";
	BINDING_NAME_CT_HOTBAR1BUTTON11 = "Button 11";
	BINDING_NAME_CT_HOTBAR1BUTTON12 = "Button 12";

	BINDING_HEADER_CT_HOTBAR2 = "Buttons der rechten Zusatzleiste";
	BINDING_NAME_CT_HOTBAR2BUTTON1 = "Button 1";
	BINDING_NAME_CT_HOTBAR2BUTTON2 = "Button 2";
	BINDING_NAME_CT_HOTBAR2BUTTON3 = "Button 3";
	BINDING_NAME_CT_HOTBAR2BUTTON4 = "Button 4";
	BINDING_NAME_CT_HOTBAR2BUTTON5 = "Button 5";
	BINDING_NAME_CT_HOTBAR2BUTTON6 = "Button 6";
	BINDING_NAME_CT_HOTBAR2BUTTON7 = "Button 7";
	BINDING_NAME_CT_HOTBAR2BUTTON8 = "Button 8";
	BINDING_NAME_CT_HOTBAR2BUTTON9 = "Button 9";
	BINDING_NAME_CT_HOTBAR2BUTTON10 = "Button 10";
	BINDING_NAME_CT_HOTBAR2BUTTON11 = "Button 11";
	BINDING_NAME_CT_HOTBAR2BUTTON12 = "Button 12";

	BINDING_HEADER_CT_HOTBAR3 = "Buttons der linken Seitenleiste";
	BINDING_NAME_CT_HOTBAR3BUTTON1 = "Button 1";
	BINDING_NAME_CT_HOTBAR3BUTTON2 = "Button 2";
	BINDING_NAME_CT_HOTBAR3BUTTON3 = "Button 3";
	BINDING_NAME_CT_HOTBAR3BUTTON4 = "Button 4";
	BINDING_NAME_CT_HOTBAR3BUTTON5 = "Button 5";
	BINDING_NAME_CT_HOTBAR3BUTTON6 = "Button 6";
	BINDING_NAME_CT_HOTBAR3BUTTON7 = "Button 7";
	BINDING_NAME_CT_HOTBAR3BUTTON8 = "Button 8";
	BINDING_NAME_CT_HOTBAR3BUTTON9 = "Button 9";
	BINDING_NAME_CT_HOTBAR3BUTTON10 = "Button 10";
	BINDING_NAME_CT_HOTBAR3BUTTON11 = "Button 11";
	BINDING_NAME_CT_HOTBAR3BUTTON12 = "Button 12";

	BINDING_HEADER_CT_HOTBAR4 = "Buttons der rechten Seitenleiste";
	BINDING_NAME_CT_HOTBAR4BUTTON1 = "Button 1";
	BINDING_NAME_CT_HOTBAR4BUTTON2 = "Button 2";
	BINDING_NAME_CT_HOTBAR4BUTTON3 = "Button 3";
	BINDING_NAME_CT_HOTBAR4BUTTON4 = "Button 4";
	BINDING_NAME_CT_HOTBAR4BUTTON5 = "Button 5";
	BINDING_NAME_CT_HOTBAR4BUTTON6 = "Button 6";
	BINDING_NAME_CT_HOTBAR4BUTTON7 = "Button 7";
	BINDING_NAME_CT_HOTBAR4BUTTON8 = "Button 8";
	BINDING_NAME_CT_HOTBAR4BUTTON9 = "Button 9";
	BINDING_NAME_CT_HOTBAR4BUTTON10 = "Button 10";
	BINDING_NAME_CT_HOTBAR4BUTTON11 = "Button 11";
	BINDING_NAME_CT_HOTBAR4BUTTON12 = "Button 12";

	BARMOD_ONOFFTOGGLE = "Ein/Aus Schalter";
	BARMOD_NUMBUTTONS = "6/9/12 Buttons";

	BARMOD_MODNAME_PETTEX = "Textur der Spezial-Leiste";
	BARMOD_MODNAME_LEFTHB = "Linke Zusatzleiste";
	BARMOD_MODNAME_RIGHTHB = "Rechte Zusatzleiste";
	BARMOD_MODNAME_LEFTSB = "Linke Seitenleiste";
	BARMOD_MODNAME_RIGHTSB = "Rechte Seitenleiste";
	BARMOD_MODNAME_TOPHB = "Obere Zusatzleiste";
	BARMOD_MODNAME_LBB = "Buttons der linken Aktionsleiste";
	BARMOD_MODNAME_RBB = "Buttons der rechten Aktionsleiste";
	BARMOD_MODNAME_PAGELOCK = "Seite sperren";
	BARMOD_MODNAME_BUTTONLOCK = "Button sperren";
	BARMOD_MODNAME_HOTBARRESET = "Zusatzleiste zur\195\188cksetzen";
	BARMOD_MODNAME_HIDEGRID = "Verstecke unbenutzte Buttons";
	BARMOD_MODNAME_OOR = "Au\195\159er Reichweite";
	BARMOD_MODNAME_HOTKEYS = "Zeige Tastaturk\195\188rzel";
	BARMOD_MODNAME_SELFCAST = "Self Cast";
	BARMOD_MODNAME_SCKEY = "Self Cast Taste";

	BARMOD_TOOLTIP_PETTEX = "Versteckt die Hintergrundtexturen der Tier- und Klassen-Leisten.";
	BARMOD_TOOLTIP_SELFCAST = "Zaubert automatisch Spr\195\188che, die auf dich selbst anwendbar sind, auf dich.\nWenn dagegen ein freundliches Ziel erfasst wurde, wird dieser Spruch auf dieses gezaubert.";
	BARMOD_TOOLTIP_HOTKEYS = "Zeigt die tats\195\164chlichen Tastaturk\195\188rzel, keine Tastaturk\195\188rzel\noder Zahlen auf den Buttons der Aktionsleisten an.";
	BARMOD_TOOLTIP_OOR = "L\195\164\195\159t Buttons auf Aktionsleisten verblassen wenn du au\195\159er Reichweite bist.";
	BARMOD_TOOLTIP_TOPHB = "Schaltet die obere Zusatzleiste ein/aus";
	BARMOD_TOOLTIP_RIGHTSB = "Schaltet die rechte Seitenleiste ein/aus";
	BARMOD_TOOLTIP_LEFTSB = "Schaltet die linke Seitenleiste ein/aus";
	BARMOD_TOOLTIP_RIGHTHB = "Schaltet die rechte Zusatzleiste ein/aus";
	BARMOD_TOOLTIP_LEFTHB = "Schaltet die linke Zusatzleiste ein/aus";
	BARMOD_TOOLTIP_RBB = "Dr\195\188cken um die Anzahl der Buttons der rechten Seitenleiste zu \195\164ndern.";
	BARMOD_TOOLTIP_LBB = "Dr\195\188cken um die Anzahl der Buttons der linken Seitenleiste zu \195\164ndern.";
	BARMOD_TOOLTIP_PAGELOCK = "Bewirkt das beim Wechseln der Zusatzleistenseiten nur die Aktionsleiste ge\195\164ndert wird.";
	BARMOD_TOOLTIP_BUTTONLOCK = "Verhindert das Verschieben der Buttons der Zusatzleisten.";
	BARMOD_TOOLTIP_HOTBARRESET = "Setzt die Positionen aller Zusatzleisten zur\195\188ck.";
	BARMOD_TOOLTIP_HIDEGRID = "Macht unbenutzte Buttons der Zusatzleisten unsichtbar.";
	BARMOD_TOOLTIP_SCKEY = "Erlaubt es dir durch Halten dieser Taste beim Klicken des Buttons diesen Zauber auf dich selbst zu wirken.\nSchaltet zwischen keiner Taste, Alt, Strg und Shift um.\nDu kannst auch eine eigene Taste unter Tastaturk\195\188rzel definieren.";

	BARMOD_SUB_PETTEX = "Verstecke Textur";
	BARMOD_SUB_PAGELOCK = "Sperrt Seiten";
	BARMOD_SUB_BUTTONLOCK = "Sperrt Buttons";
	BARMOD_SUB_HOTBARRESET = "Setzt Positionen zur\195\188ck";
	BARMOD_SUB_HIDEGRID = "Versteckt unbenutzte Buttons";
	BARMOD_SUB_OOR = "Icons verblassen";
	BARMOD_SUB_HOTKEYS = "3 Modi";
	BARMOD_SUB_SELFCAST = "smartes Zaubern";
	BARMOD_SUB_SCKEY = "Tastenmodifikator";

	BARMOD_OFF_BUTTONGRID = "<CTMod> Unbenutzte Buttons werden nun angezeigt.";
	BARMOD_ON_BUTTONGRID = "<CTMod> Unbenutzte Buttons werden nun versteckt.";

	BARMOD_ON_TOPBAR = "<CTMod> Die obere Zusatzleiste wird nun angezeigt.";
	BARMOD_OFF_TOPBAR = "<CTMod> Die obere Zusatzleiste wird nun versteckt.";

	BARMOD_ON_LEFTHBAR = "<CTMod> Die linke Zusatzleiste wird nun angezeigt.";
	BARMOD_OFF_LEFTHBAR = "<CTMod> Die linke Zusatzleiste wird nun versteckt.";

	BARMOD_ON_RIGHTHBAR = "<CTMod> Die rechte Zusatzleiste wird nun angezeigt.";
	BARMOD_OFF_RIGHTHBAR = "<CTMod> Die rechte Zusatzleiste wird nun versteckt.";

	BARMOD_ON_LEFTSBAR = "<CTMod> Die linke Seitenleiste wird nun angezeigt.";
	BARMOD_OFF_LEFTSBAR = "<CTMod> Die linke Seitenleiste wird nun versteckt.";

	BARMOD_ON_RIGHTSBAR = "<CTMod> Die rechte Seitenleiste wird nun angezeigt.";
	BARMOD_OFF_RIGHTSBAR = "<CTMod> Die rechte Seitenleiste wird nun versteckt.";

	BARMOD_ON_HOTBARBUTTONS = "<CTMod> Die Buttons der Zusatzleisten sind nun gesperrt.";
	BARMOD_OFF_HOTBARBUTTONS = "<CTMod> Die Buttons der Zusatzleisten sind nun entsperrt.";

	BARMOD_ON_OOR1 = "<CTMod> Die Buttons der Aktionsleisten werden nun grau wenn du au\195\159er Reichweite bist.";
	BARMOD_ON_OOR2 = "<CTMod> Die Buttons der Aktionsleisten werden nun rot wenn du au\195\159er Reichweite bist.";
	BARMOD_OFF_OOR = "<CTMod> Die Buttons der Aktionsleisten \195\164ndern nicht l\195\164nger ihre Farbe wenn du au\195\159er Reichweite bist.";

	BARMOD_ON_SELFCAST = "<CTMod> Self Cast ist nun eingeschaltet.";
	BARMOD_OFF_SELFCAST = "<CTMod> Self Cast ist nun ausgeschaltet.";

	BARMOD_ON_PETTEX = "<CTMod> Textur der Spezialleiste wird nun angezeigt.";
	BARMOD_OFF_PETTEX = "<CTMod> Textur der Spezialleiste wird nun versteckt.";

	BARMOD_ON_HOTKEY1 = "<CTMod> Tastaturk\195\188rzel zeigen nun Nummern.";
	BARMOD_ON_HOTKEY2 = "<CTMod> Tastaturk\195\188rzel zeigen nun ihre tats\195\164chlichen Bindungen.";
	BARMOD_OFF_HOTKEY = "<CTMod> Tastaturk\195\188rzel zeigen nicht l\195\164nger Bindungen.";

	BARMOD_ON_SCKEY1 = "<CTMod> Self Cast Taste ist nun auf Strg gesetzt.";
	BARMOD_ON_SCKEY2 = "<CTMod> Self Cast Taste ist nun auf Alt gesetzt.";
	BARMOD_ON_SCKEY3 = "<CTMod> Self Cast Taste ist nun auf Shift gesetzt.";
	BARMOD_ON_SCKEY4 = "<CTMod> Self Cast Taste ist nun nicht mehr gesetzt.";

end