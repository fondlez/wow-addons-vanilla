-- Version : French ( by Sasmira )
-- Last Update : 03/29/2005


if ( GetLocale() == "frFR" ) then

CT_ITEMBUFFS_CHARGE = "Charge";
CT_ITEMBUFFS_MINUTE = "min";
CT_ITEMBUFFS_SECOND = "sec";

CT_ITEMBUFFS_MODNAME = "Buffs d\'Objet";
CT_ITEMBUFFS_SUBNAME = "Afficher des petits buffs d\'Objet";
CT_ITEMBUFFS_TOOLTIP = "Affiche/Cache Les Buffs d\'Objet pendant 15 secondes dans la liste des Buffs.";

end