if ( GetLocale() == "deDE" ) then
	CT_ITEMBUFFS_MODNAME = "Item-Buffs";
	CT_ITEMBUFFS_SUBNAME = "Zeige kurze Buffs";
	CT_ITEMBUFFS_TOOLTIP = "Schaltet die Anzeige von Buffs die k\195\188rzer als 15 Sekunden sind in der Buff-Leiste ein/aus.";

	CT_ITEMBUFFS_SHORTDURATION_SHOWN = "Kurze Buffs werden nun angezeigt.";
	CT_ITEMBUFFS_SHORTDURATION_HIDDEN = "Kurze Buffs werden nun versteckt.";
end