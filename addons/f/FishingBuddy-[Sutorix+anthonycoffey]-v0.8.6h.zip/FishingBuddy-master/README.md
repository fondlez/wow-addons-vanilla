# FishingBuddy
vanilla world of warcraft addon that I've made updates to in order to fix in-game bugs
