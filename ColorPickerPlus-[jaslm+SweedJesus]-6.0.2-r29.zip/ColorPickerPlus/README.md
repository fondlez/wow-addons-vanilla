# ColorPickerPlus (1.12 version)

Original: http://www.curse.com/addons/wow/colorpickerplus

Adds improved features to the existing Blizzard color picker widget. Features
like copying and pasting colors, RGBA channel values, hex value and color
swatches for the old color and color in the copy buffer.
