# JIM_CooldownPulse

As spells, actions, and items become available, their icons will flash in a conspicuous place.
