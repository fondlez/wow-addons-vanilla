local A = FonzAppraiser

A.HELP_VERSION = [[Version 1.0.0 - 2022-02-02 |cffffffff
[+] Initial public release.
|r
]]
