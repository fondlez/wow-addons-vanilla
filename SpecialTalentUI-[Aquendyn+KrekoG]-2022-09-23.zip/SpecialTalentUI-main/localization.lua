SPECIAL_TALENT = "Special Talent";
TALENT_POINTS = "Talent Points";
UNSPENT_POINTS = "Unspent Points";
TALENTS_LEARNED = "Learned";
TALENTS_PLANNED = "Planned";
SHIFT_CLICK_LEARN_TALENT = "Force Shift-click to Learn";
PLANNED_RANK = "Planned Rank %d/%d";