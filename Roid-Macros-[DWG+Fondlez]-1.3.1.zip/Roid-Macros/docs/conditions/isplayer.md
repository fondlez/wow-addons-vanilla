# isplayer

This condition will only fire when the specified UnitID is a player.

## Parameters

The target's UnitID. Refer to [target condition](target.md).

## Examples

```lua
/cast [isplayer:target] {Yes}
```

This will execute the Macro with the name `Yes` if your target is a player.
