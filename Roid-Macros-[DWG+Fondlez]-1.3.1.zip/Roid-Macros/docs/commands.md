# Chat Commands

* [/petattack](commands/petattack.md)
* [/equip](commands/equip.md)
* [/startattack](commands/startattack.md)
* [/stopattack](commands/stopattack.md)
* [/stopcasting](commands/stopcasting.md)
* [/target](commands/target.md)
* [/unshift](commands/unshift.md)
* [/use](commands/use.md)
* [/rl](commands/reload.md)